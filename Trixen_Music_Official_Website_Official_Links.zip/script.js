// Official Trixen Music links supplied by the artist.
const TRIXEN_LINKS = {
  spotify: "https://open.spotify.com/artist/7qW5MQNVZCVYdrrqgVqYuf",
  youtube: "https://youtube.com/@tanishkmusicstudio",
  instagram: "https://www.instagram.com/trixen.music",
  facebook: "https://www.facebook.com/share/1Mn6EFhn9L/"
};

document.querySelectorAll("[data-link]").forEach((link) => {
  const destination = TRIXEN_LINKS[link.dataset.link];
  if (destination) {
    link.href = destination;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
  }
});

const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});
mainNav.querySelectorAll("a").forEach((item) => {
  item.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});
document.getElementById("year").textContent = new Date().getFullYear();
