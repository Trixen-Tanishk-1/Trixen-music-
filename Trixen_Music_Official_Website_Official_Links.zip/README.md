# Trixen Music — Official Artist Website

A responsive, single-page artist website with a black-and-gold luxury look. Built with plain HTML, CSS and JavaScript; no paid software or build tools required.

## Included files
- `index.html` — website content and sections
- `style.css` — responsive design and styling
- `script.js` — mobile menu and social/music links

## Before publishing
1. Open `script.js` in a text editor.
2. Replace the `#` values in `TRIXEN_LINKS` with your real Spotify, YouTube and Instagram URLs.
3. In `index.html`, update the About paragraph and any release details you want to change.
4. To use your own photos/cover artwork, add image files to this folder and update the relevant CSS/HTML. The current release artwork is a CSS illustration, so the site works without extra image files.

## Publish free with GitHub Pages
1. Sign in or create a free account at https://github.com/.
2. Create a new **Public** repository named `trixen-music` (or any name you like).
3. Upload `index.html`, `style.css`, and `script.js` to the repository's root. You can upload this ZIP's extracted files using **Add file → Upload files**.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then click **Save**.
7. Wait a few minutes. GitHub will show your website address, usually:
   `https://YOUR-USERNAME.github.io/trixen-music/`

If the repository is named `YOUR-USERNAME.github.io`, the address will instead be:
`https://YOUR-USERNAME.github.io/`

## Updating the website
Edit a file locally, then upload/commit the changed file to the same repository. GitHub Pages republishes it automatically.

## Important
- GitHub Pages hosting is free for public repositories.
- The site does not process payments or collect visitor data.
- The Spotify/YouTube/Instagram buttons need your real URLs added in `script.js`; they intentionally do not point to invented profiles.
- The Google Fonts connection requires internet access. System fonts are used as fallback if unavailable.


## Default working links
The Listen Now button opens Spotify search for 'Raat Ka Khumaar Tanishk Sharma'; YouTube opens a matching YouTube search; Instagram opens Instagram. Replace these with your exact artist/song profile URLs in `script.js` when you have them.


## Official artist links configured
- YouTube: https://youtube.com/@tanishkmusicstudio
- Spotify: https://open.spotify.com/artist/7qW5MQNVZCVYdrrqgVqYuf
- Instagram: https://www.instagram.com/trixen.music
- Facebook: https://www.facebook.com/share/1Mn6EFhn9L/
- Email: tanishksharma634@gmail.com

The homepage Spotify button opens the Spotify artist profile, and the YouTube button opens the YouTube channel. To link directly to the individual "Raat Ka Khumaar" track/video, replace those destinations with the exact track/video URLs once available.
